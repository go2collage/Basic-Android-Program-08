package com.go2collage.practical_08;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare variables
    private EditText name, dob, address, email, contact;
    private Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize variables
        submit = findViewById(R.id.submitbtn);

        name = findViewById(R.id.edName);
        dob = findViewById(R.id.edDob);
        address = findViewById(R.id.edAddress);
        email = findViewById(R.id.edEmail);
        contact = findViewById(R.id.edContact);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // converting text to String
                String n = name.getText().toString();
                String d = dob.getText().toString();
                String add = address.getText().toString();
                String e = email.getText().toString();
                String number = contact.getText().toString();

                // if any fields is empty then
                if (n.isEmpty() || d.isEmpty() || add.isEmpty() || e.isEmpty() || number.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
                }

                // else all the fields filled then
                else {
                    Toast.makeText(MainActivity.this, n +"\n"+ d +"\n"+ add +"\n"+ e +"\n"+ number, Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}